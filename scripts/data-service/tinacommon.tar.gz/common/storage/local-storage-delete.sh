#!/bin/bash

kubectl delete pv $(kubectl get pv | grep pv-mssql | awk '{print $1}') 2>/dev/null || true
kubectl delete sc local-storage 2>/dev/null || true

# Delete the underlying directories used by the PVs
#
sudo rm -rf /var/tmp/aris/pv /tmp/aris/pv
