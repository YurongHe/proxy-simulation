#!/bin/bash
if [ $# -lt 2 ]; then
  echo "usage: ./label-nodes.sh <machineName> <labelValue>"
  exit
fi

machineName=$1
labelValue=$2

kubectl label node $machineName mssql-resource=$labelValue
