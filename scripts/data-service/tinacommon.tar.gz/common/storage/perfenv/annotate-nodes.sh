#!/bin/bash
if [ $# -lt 2 ]; then
  echo "usage: annotate <POOL_TYPE: data-pool|storage-pool|spark-pool> NODE1 NODE2 ..."
  exit
fi

POOL=$1
shift

while [ $# -gt 0 ]
do
  NODE=$1
  echo "annotate $POOL node $NODE"
  kubectl annotate nodes $NODE pv-$POOL=true
  shift
done

