#!/bin/bash

# This script provisions/deprovisions local pv according to node annotations.
#
# Annotate nodes with the following pool name prior to calling this script:
# - storage-pool
# - data-pool
# - spark-pool
#
# Note if pool name annotation does not exist across all kubernetes nodes, 
# it won't create local pv for that pool
#
# Usage:
# setup-local-pv-annotated.sh [delete|apply] [ssd_mount] [hdd_mount] [general_use_pv_count]
# The ssd_mount is the mount path on each node for local SSD, used by 
# general-use and data-pool pvs.
# The hdd_mount is the mount path on each node for local HDD, used by
# storage-pool and spark-pool pvs.
# The general_use_pv_count is the number of general use pv for each node.
# The default value is 6.

general_use_pv_num=6
if [ "$4" != "" ]; then
  general_use_pv_num=$4
fi
. setenv.sh $general_use_pv_num

# ------ Read parameters ------
scriptPath=`dirname $0`
# To clean up, pass in "delete" as first parameter, otherwise create
if [ "$1" == "delete" ]; then
  export KUBECTL_VERB=delete
  export DIR_ACTION="rm -rf"
else
  export KUBECTL_VERB=apply
  export DIR_ACTION="mkdir -p"
fi

export SSD_MOUNT=/mnt
if [ "$2" != "" ]; then
  export SSD_MOUNT=$2
fi
export HDD_MOUNT=/mnt
if [ "$3" != "" ]; then
  export HDD_MOUNT=$3
fi
# ------ Done reading parameters ------

# Get all k8s worker nodes, we'll create general use (logs etc.) PVs on all nodes (except k8s master)
ALL_NODES=($(kubectl get nodes --selector='!node-role.kubernetes.io/master' -o custom-columns=IP:.metadata.name --no-headers))
# Get all node names annotated as data-pool candidates
IFS=' ' read -r -a DATA_POOL_NODES <<< `kubectl get nodes -o jsonpath='{.items[?(@.metadata.annotations.pv-data-pool=="true")].metadata.name}'`
# Get all node names annotated as storage-pool candidates
IFS=' ' read -r -a STORAGE_POOL_NODES <<< `kubectl get nodes -o jsonpath='{.items[?(@.metadata.annotations.pv-storage-pool=="true")].metadata.name}'`
# Get all node names annotated as spark-pool candidates
IFS=' ' read -r -a SPARK_POOL_NODES <<< `kubectl get nodes -o jsonpath='{.items[?(@.metadata.annotations.pv-spark-pool=="true")].metadata.name}'`

# create (or delete) a PV in k8s and create (or delete) the physical directory structure on the actual node
function create_local_pv {
  envsubst < $scriptPath/pv-local-storage.yaml.tmpl > $scriptPath/pv-local-storage.yaml
  kubectl $KUBECTL_VERB -f $scriptPath/pv-local-storage.yaml
  echo "ssh -t -q root@$node_name sudo $DIR_ACTION $PV_LOCAL_PATH"
  ssh -t -oStrictHostKeyChecking=no root@$node_name sudo $DIR_ACTION $PV_LOCAL_PATH
  rm $scriptPath/pv-local-storage.yaml
}

# set_pv_exports pv_use root_path volume_number
function set_pv_exports {
  export PV_NAME="pv-$CLUSTER_NAME-$1-$PV_HOSTNAME-$3"
  export PV_LOCAL_PATH="$2/$CLUSTER_NAME-$1-vol-$3"
  create_local_pv
}

# create_volumes_per_node volume_count pv_use root_path
function create_volumes_per_node {
  for volume_number in `seq 1 $1`; do
    set_pv_exports $2 $3 $volume_number
  done
}

# create_local_pvs volume_count pv_use root_path storage_class storage_size node0 node1 ...
function create_local_pvs {
  volume_count=$1; shift
  pv_use=$1; shift
  root_path=$1; shift
  export PV_SC=$1; shift
  export PV_SIZE=$1; shift

  for node_name in "$@"; do
    echo "creating pv on $node_name"
    export PV_HOSTNAME="$node_name"
    create_volumes_per_node $volume_count $pv_use $root_path
  done
}

# The controller and monitor services need a few general use PVs on a single node, we'll
# provision all nodes with enough general use PVs such that each could host them
create_local_pvs $GENERAL_USE_PV_COUNT "general-use" "$SSD_MOUNT" "$GENERAL_USE_STORAGE_CLASS_NAME" "$GENERAL_USE_STORAGE_SIZE" "${ALL_NODES[@]}"
create_local_pvs $DATA_POOL_PV_COUNT "data-pool" "$SSD_MOUNT" "$DATA_POOL_STORAGE_CLASS_NAME" "$DATA_POOL_STORAGE_SIZE" "${DATA_POOL_NODES[@]}"
create_local_pvs $STORAGE_POOL_PV_COUNT "storage-pool" "$HDD_MOUNT" "$STORAGE_POOL_STORAGE_CLASS_NAME" "$STORAGE_POOL_STORAGE_SIZE" "${STORAGE_POOL_NODES[@]}"
create_local_pvs $SPARK_POOL_PV_COUNT "spark-pool" "$HDD_MOUNT" "$SPARK_POOL_STORAGE_CLASS_NAME" "$SPARK_POOL_STORAGE_SIZE" "${SPARK_POOL_NODES[@]}"
