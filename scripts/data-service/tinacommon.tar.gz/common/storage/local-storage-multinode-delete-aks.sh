#!/bin/bash

PV_COUNT=25

# Delete the storage class and namespace for local-storage provisioner
#
kubectl delete storageclass local-storage 2>/dev/null || true
echo "'local-storage' storageclass deleted"
kubectl delete ns local-storage 2>/dev/null || true
echo "Name space 'local-storage' deleted"

# Delete any old PVs
#
kubectl delete pv $(kubectl get pv | grep local-pv | awk '{print $1}') 2>/dev/null || true
echo "PV 'local-pv...' deleted"

kubectl delete pv $(kubectl get pv | grep pvc | awk '{print $1}') 2>/dev/null || true
echo "PV 'pvc-...' deleted"