#!/bin/bash

# if you want PVs to use local SSD("local-storage" storage class) in AKS, read 
# the following comments
# "local-storage" storage class and storage provisionor are created by default
# in AKS cluster. 
# The storage provisionor will continuously check /mnt/local-storage folder 
# if there are mounting points in this folder, then it create a PVs for them.
# In this AKS, /mnt is mounted to local SSD, so the PVs will use local SSD.
# So using local-storage storage class depends on
# setting up the bind-mount in /mnt/local-storage like following code:
# for i in $(seq 1 $PV_COUNT); do
#   vol="vol$i"
#   sudo mkdir -p /mnt/local-storage/$vol
#   sudo mount --bind /mnt/local-storage/$vol /mnt/local-storage/$vol
# done

scriptPath=`dirname $0`
kubectl apply -f $scriptPath/local-storage-provisioner-aks.yaml
