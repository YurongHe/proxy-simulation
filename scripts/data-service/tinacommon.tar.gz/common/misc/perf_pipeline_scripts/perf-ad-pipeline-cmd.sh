#!/bin/bash -e

# This is the script to kick off Spark perf tests, it is not using the yaml files
# in aris test scheduler because we don't want to delete cluster after it is done.
# No need to call copy-logs as it is a post build step.

# general use pv count for each node is 6
source projects/common/misc/perf_pipeline_scripts/jenkins_kubernetes_setup.sh /data 6
make deploy-latest PERF=1 AD=1 USE_LAB_DC=1
make run-ad-perf-tests-latest
