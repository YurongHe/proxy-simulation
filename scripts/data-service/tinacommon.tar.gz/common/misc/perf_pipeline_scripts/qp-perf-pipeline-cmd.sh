#!/bin/bash -e

# general-use-pv-count for each node is 12
source projects/common/misc/perf_pipeline_scripts/jenkins_kubernetes_setup.sh /data-raid0 12

# label bdc master node, be aware that this is different from the master node of k8s
projects/common/storage/perfenv/label-nodes.sh `cat ~/bdc-master-node` bdc-master

# label bdc compute pool nodes
IFS=' ' read -r -a computenodes <<< `cat ~/bdc-compute-nodes`
for computenode in "${computenodes[@]}" 
do
    projects/common/storage/perfenv/label-nodes.sh $computenode bdc-compute-pool
done

make deploy-latest QPPERF=1

# To enable/disable publishing perf run numbers to sql perf database
export BDC_PERF_RUN=True

make run-qp-perf-tests-latest
make copy-logs
