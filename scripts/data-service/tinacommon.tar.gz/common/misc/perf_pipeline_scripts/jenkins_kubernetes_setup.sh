#!/bin/bash -e

# This script sets up jenkins kubernetes for perf lab run.
# This script is shared between Spark perf and Aris QP perf.

# Usage:
# jenkins_kubernetes_setup.sh [raid_path] [general_use_pv_count]
# raid_path: specify the path that's mapped to RAID disk on the perf machines. Default is /data.
# general_use_pv_count: set the number of general use pv generated in setup-local-pv-annotated.sh. Default is 6.

# ------ Read parameters ------
raid_path=/data
if [ "$1" != "" ]; then
  raid_path=$1
fi

general_use_pv_num=6
if [ "$2" != "" ]; then
  general_use_pv_num=$2
fi

git clean -fdx
make distclean
set +e
# make deploy-clean can fail if there is no cluster to clean
make deploy-clean
set -e
export DOCKER_DIR=$raid_path/docker
export KUBELET_DIR=$raid_path/kubelet
sudo -E DOCKER_DIR=$raid_path/docker KUBELET_DIR=$raid_path/kubelet projects/common/reset-multi-node-kubeadm.sh `cat ~/workerhosts`
sudo -E DOCKER_DIR=$raid_path/docker KUBELET_DIR=$raid_path/kubelet projects/common/start-multi-node-kubeadm.sh `cat ~/masterhost` `cat ~/workerhosts`
pushd projects/common/storage/perfenv
kubectl apply -f ../sc-local-storage.yaml
kubectl apply -f sc-data-pool-local-storage.yaml
kubectl apply -f sc-storage-pool-local-storage.yaml
kubectl apply -f sc-spark-pool-local-storage.yaml
./annotate-nodes.sh storage-pool `cat ~/storagehosts`
./annotate-nodes.sh data-pool `cat ~/datahosts`
sudo ./setup-local-pv-annotated.sh delete $raid_path $raid_path $general_use_pv_num
sudo ./setup-local-pv-annotated.sh apply $raid_path $raid_path $general_use_pv_num

popd
export DOCKER_IMAGE_TAG=latest