import os
import re 
import sys
import subprocess
import argparse
import time

FILE_CONTENTS = "This is a lock file for the resource tracker process! Please delete this to continue!"
WRITE_FREQUENCY = 1
SLEEP_DURATION = 0
POD_MIN = 10

class PodData:
    def __init__(self, podName):
        self.podName = podName
        self.containers = dict()
        self.containerList = []

    def addStats(self, containerName, cpu, memory):
        if containerName not in self.containers:
            containerData = ContainerData(containerName)
            self.containers[containerName] = containerData
            self.containerList.append(containerData)
        containerData = self.containers[containerName]
        containerData.addCPU(cpu)
        containerData.addMemory(memory)

    def __repr__(self):
        finalResult = []
        finalResult.append("Pod: %s" % self.podName)
        for container in self.containerList:
            indentedRepr = "\t" + "\n\t".join(container.__repr__().split("\n"))
            finalResult.append(indentedRepr)

        statTuples = [[container.cpuMin, container.cpuMax, container.memoryMin, container.memoryMax] for container in self.containerList]
        cpuMin, cpuMax, memoryMin, memoryMax = [sum(prop) for prop in list(zip(*statTuples))] #A tuple of cpu min/max and mem min/max
        finalResult.append("\tTotal CPU range: %sm - %sm" % (cpuMin, cpuMax))
        finalResult.append("\tTotal memory range: %sMi - %sMi" % (memoryMin, memoryMax))
        finalResult.append("\n")
        return "\n".join(finalResult)

class FileLock:
    def __init__(self, lockFileName):
        self.lockFileName = lockFileName

    def writeFileLock(self):
        if self.exists():
            with open(self.lockFileName, "r") as f:
                if f.read() != FILE_CONTENTS:
                    raise Exception("The existing file %s is not a valid lock file. Please remove this or change the lock file name." % self.lockFileName)
        else:
            with open(self.lockFileName, "w+") as f:
                f.write(FILE_CONTENTS)
                print("Created the lock file %s. Please delete this to stop the pod resource tracker." % self.lockFileName)

    def deleteFileLock(self):
        if not self.exists():
            raise Exception("The lock file %s does not exist. The tracker has most likely been stopped." % self.lockFileName)
        with open(self.lockFileName, "r") as f:
            if f.read() != FILE_CONTENTS:
                raise Exception("The lock file %s has been modified. Please delete it manually." % self.lockFileName)
        os.remove(self.lockFileName)
        print("Tracker associated with %s stopped!" % self.lockFileName)

    def exists(self):
        return os.path.exists(self.lockFileName)


class ContainerData:
    def __init__(self, containerName):
        self.containerName = containerName
        self.cpuMin = None
        self.cpuMax = None
        self.memoryMin = None
        self.memoryMax = None

    def addCPU(self, cpu):
        if self.cpuMin == None:
            self.cpuMin = cpu
        else:
            self.cpuMin = min(self.cpuMin, cpu)
        if self.cpuMax == None:
            self.cpuMax = cpu
        else:
            self.cpuMax = max(self.cpuMax, cpu)

    def addMemory(self, memory):
        if self.memoryMin == None:
            self.memoryMin = memory
        else:
            self.memoryMin = min(self.memoryMin, memory)
        if self.memoryMax == None:
            self.memoryMax = memory
        else:
            self.memoryMax = max(self.memoryMax, memory)

    def __repr__(self):
        result =  ["Service: %s" % (self.containerName), 
                   "\tCPU range: %sm - %sm" % (self.cpuMin, self.cpuMax),
                   "\tMemory range: %sMi - %sMi" % (self.memoryMin, self.memoryMax)]
        return "\n".join(result)

class LimitTracker:
    limitRegex = re.compile(r"([^ ]+)[ ]+([^ ]+)[ ]+([0-9]+)m[ ]+([0-9]+)Mi")
    topRegex = re.compile("([^ \n]+)[ ]+[0-9]+\/[0-9]+[ ]+([^ \n]+)[ ]+[0-9]+[ ]+([^\W]+)")
    currentDir = os.path.dirname(os.path.realpath(__file__))
    def __init__(self, lock, writeFileName):
        try:
            self.results = dict()
            self.lock = lock
            self.writeFileName = writeFileName
            self.counter = 0
            self.needsTeardown = False
            self.setup()
            self.start()
        except:
            raise
        finally:
            self.teardown()
                

    def setup(self):
        #We need to see if metrics-server is installed
        if not self.isMetricsServerInstalled():
            #Attempt to preserve the original state of the cluster. Teardown after completion.
            self.installMetricsServer()
            self.needsTeardown = True
        #It's technically not necessary to wait for metrics-server,
        #since we try-catch each top attempt.

    def isMetricsServerInstalled(self):
        deployments = self.runCommand("kubectl -n kube-system get deployment")
        return "metrics-server" in deployments

    def installMetricsServer(self):
        self.runCommand("kubectl create -f %s/metrics-server" % self.currentDir)
        time.sleep(60) #Metrics-server deployment delay

    def teardownMetricsServer(self):
        self.runCommand("kubectl delete -f %s/metrics-server" % self.currentDir)



    def teardown(self):
        if self.needsTeardown:
            self.teardownMetricsServer()
        
    def runCommand(self, command):
        result = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
        return result

    def start(self):
        self.interestingPods = self.getInterestingPods()
        self.lock.writeFileLock()
        self.printInitialDiagnostics()
        while self.lock.exists():
            self.updatePods()
            if self.counter % WRITE_FREQUENCY == 0:
                self.writeResults()
            self.counter += 1
            time.sleep(SLEEP_DURATION)
        self.printEndDiagnostics()

    def writeResults(self):
        if self.writeFileName:
            results = self.formatResult()
            with open(self.writeFileName, "w+") as f:
                f.write(results)

    def formatResult(self):
        listResult = []
        listResult.append("The pod resource tracker ran for %s loops." % self.counter)
        for pod in self.results:
            entry = self.results[pod]
            listResult.append(str(entry))
        return "\n".join(listResult)

    def printInitialDiagnostics(self):
        formattedPods = ", ".join(self.interestingPods)
        if self.writeFileName:
            print("Writing results to %s." % self.writeFileName)
        else:
            print("Not writing results anywhere.")
        print("Beginning to track the following pods: %s" % formattedPods)

    def printEndDiagnostics(self):
        self.writeResults()
        print(self.formatResult())

    def updatePods(self):
        for pod in self.interestingPods:
            try:
                rawTopResult = self.topPod(pod)
                self.processResult(rawTopResult)
            except subprocess.CalledProcessError as e:
                expectedError = "the server is currently unable to handle the request"
                expectedError2 = "podmetrics.metrics.k8s.io \"test"
                if expectedError not in e.output and expectedError2 not in e.output:
                    print("Somehow got %s" % e.output)
                    raise
                print("Metrics-server not up yet, sleeping for 60 seconds")
                time.sleep(60)

    def topPod(self, pod):
        rawTopResult = self.runCommand("kubectl -n test top pod %s --containers" % pod)
        return rawTopResult

    def processResult(self, rawTopResult):
        matchResult = self.limitRegex.findall(rawTopResult)
        if matchResult:
            for podData in matchResult:
                pod, container, cpu, memory = podData
                cpu = int(cpu)
                memory = int(memory)
                if pod not in self.results:
                    self.results[pod] = PodData(pod)
                finalPodData = self.results[pod]
                finalPodData.addStats(container, cpu, memory)
        else:
            print("Failed with the following error:\n%s\nNot adding result." % rawTopResult)
    
    def getInterestingPods(self):
        try:
            podNames = self.runCommand("kubectl -n test get pods")
        except Exception as e:
            print("Kubectl command failed. Make sure that the test cluster is up.")
            raise
        allPodNames = [entry[0] for entry in self.topRegex.findall(podNames)]
        return [pod for pod in allPodNames if self.isPodNameInteresting(pod)]

    def isPodNameInteresting(self, pod):
        if "driver" in pod or "executor" in pod:
            return False
        if ("spark" in pod or "nmnode" in pod or "storage" in pod
         or "zookeeper" in pod or "gateway" in pod):
            return True
        return False

# limitTrack = LimitTracker()
# for i in range (0, 200):
#     limitTrack.updatePods()
# limitTrack.interpretResult()


def clusterSanityCheck():
    """A quick sanity check to ensure that the cluster is running"""
    podRetrievalCommand = "kubectl -n test get pods".split(" ")
    podNames = subprocess.check_output(podRetrievalCommand)
    if (podNames.count("\n") < POD_MIN):
        raise Exception("Fewer than 10 pods detected. The cluster is likely not set up properly. Aborting.")
    

def main():
    parser = argparse.ArgumentParser("Kubernetes cluster resource tracker")
    parser.add_argument('-s', '--stop', dest="stop", action='store_true', help="Should be specified if deleting the lock.")
    parser.add_argument('-l', '--lock', dest="lock", help="A lock file that should be deleted to stop the tracker.", required = True)
    parser.add_argument('-w', '--write', dest="write", help="A file to write the results to.")
    parser.add_argument('-d', '--daemon', dest="daemon", action='store_true', help="Should be specified if running in daemon mode.")
    # Writing is optional in all cases--if starting, the results are printed anyways, and if stopping, it's not needed.

    args = parser.parse_args(sys.argv[1:])
    shouldStop, lockFileName, writeFileName, daemon = args.stop, args.lock, args.write, args.daemon
    lock = FileLock(lockFileName)
    if daemon:
        #Rerun this as a daemon process
        handleDaemon(lock)
    elif shouldStop:
        handleStop(lock)
    else:
        printDebugInfo(writeFileName)
        handleStart(lock, writeFileName)

def printDebugInfo(writeFileName):
    if writeFileName:
        print("Writing results to %s." % writeFileName)
    else:
        print("Not writing results anywhere.")

def handleStart(lock, writeFileName):
    LimitTracker(lock, writeFileName)

def handleStop(lock):
    lock.deleteFileLock()

def handleDaemon(lock):
    clusterSanityCheck()
    lock.writeFileLock() #Locking is idempotent; no harm in doing it early
    allArgs = [arg for arg in sys.argv if (arg != "-d" and arg != "--daemon")]
    subprocess.Popen(["python"] + allArgs)
    print("Pod resource tracking daemon with arguments %s started!" % " ".join(allArgs))

if __name__ == "__main__":
    main()

