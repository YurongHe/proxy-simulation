#!/bin/bash

# This script takes a list of worker ips as input arguments, and resets kubeadm at master host and
# all the worker nodes specified by the input ips.

if [ "$EUID" -ne 0 ]
  then echo "Please run as root"
  exit
fi

# Get the directory of the scripts
SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
while [ $# -gt 0 ]
do
    # sometimes, people add non-breaking space characters to their *host* files that break our parsing.
    WORKER_IP=$(echo "$1" | sed -e 's/\xC2\xA0//g')
    echo -e "\e[42mresetting on worker ${WORKER_IP}\e[0m"
    # Copy the scripts to worker nodes
    scp -oStrictHostKeyChecking=no $SCRIPT_DIR/cleanup-mount-services.sh root@$WORKER_IP:/root/cleanup-mount-services.sh
    scp -oStrictHostKeyChecking=no $SCRIPT_DIR/common-node.sh root@$WORKER_IP:/root/common-node.sh
    scp -oStrictHostKeyChecking=no $SCRIPT_DIR/reset-kubeadm.sh root@$WORKER_IP:/root/reset-kubeadm.sh
    # Reset kubeadm at worker nodes
    ssh -oStrictHostKeyChecking=no root@$WORKER_IP "/root/reset-kubeadm.sh"

    shift
done

# Parallelize docker image pruning to reduce the cluster deployment time. Sequential docker image pruning takes more than hour.
echo "Docker images pruning started"
export WCOLL=~/workerhosts
export PDSH_RCMD_TYPE=ssh
export PDSH_SSH_ARGS_APPEND='-oStrictHostKeyChecking=no'
pdsh -R ssh docker image prune -f
echo "Docker images pruning ended"
# Parallelize uninstallation of docker-ce to prevent upgrading it which has a full screen promt
echo "Remove docker-ce docker-ce-cli started"
pdsh -R ssh apt-get -y remove docker-ce docker-ce-cli
echo "Remove docker-ce docker-ce-cli ended"

# Reset kubeadm at master host
echo -e "\e[42mresetting master `hostname`\e[0m"
$SCRIPT_DIR/reset-kubeadm.sh
# Prune docker images
docker image prune -f
apt-get -y remove docker-ce docker-ce-cli