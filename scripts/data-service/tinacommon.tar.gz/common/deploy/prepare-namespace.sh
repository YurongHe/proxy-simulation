#!/bin/bash

set -e
DIR=`dirname $0`

source $DIR/utils.sh

function prepare-ocp {
    if [ "$ROOT" = "" ]; then
        SCC=bdc-restricted-scc
        $OC apply -f ${DIR}/${SCC}.yaml
    else
        SCC=anyuid
    fi

    kubectl create namespace ${CLUSTER_NAME}
    $OC label namespace ${CLUSTER_NAME} MSSQL_CLUSTER=${CLUSTER_NAME}

    if [ "$ROOT" = "" ]; then
        $OC adm policy add-scc-to-group ${SCC} system:serviceaccounts:${CLUSTER_NAME}

        # There must be already a kubeuser setup in Identity Provider
        #
        $OC adm policy add-role-to-user cluster-admin kubeuser -n ${CLUSTER_NAME}
    else
        SCC=privileged
        $OC adm policy add-scc-to-group ${SCC} system:serviceaccounts:${CLUSTER_NAME}
    fi
}

function prepare-kube {
    if [ "$ROOT" = "" ]; then
        POLICY=bdc-psp
        kubectl apply -f ${DIR}/../policy/${POLICY}.yaml
    else
        POLICY=privileged
    fi

    kubectl create namespace ${CLUSTER_NAME}
    kubectl label namespace ${CLUSTER_NAME} MSSQL_CLUSTER=${CLUSTER_NAME}

    if [ "$ROOT" = "" ]; then
        kubectl create clusterrole bdc-user -n ${CLUSTER_NAME} --verb=use --resource=podsecuritypolicy --resource-name=$POLICY || true
        kubectl create rolebinding namespace:bdc-user -n ${CLUSTER_NAME} --clusterrole=bdc-user --group=system:serviceaccounts:${CLUSTER_NAME} --user=kubeuser

        # There must be already a kubeuser user defined in kube/config
        #
        kubectl create rolebinding kubeuser:admin -n ${CLUSTER_NAME} --clusterrole=cluster-admin --user=kubeuser
    else
        kubectl create rolebinding namespace:privileged-user -n ${CLUSTER_NAME} --clusterrole=privileged-user --group=system:serviceaccounts:${CLUSTER_NAME}
    fi
}


if [ "$OCP" != "" ]; then
    prepare-ocp
else
    if is-psp-enabled; then
        prepare-kube
    fi
fi
