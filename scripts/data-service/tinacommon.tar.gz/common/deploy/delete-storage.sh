#!/bin/bash
set -e
DIR=`dirname $0`

# Delete the provided volumes
#
kubectl delete pv $(kubectl get pv | grep pv-mssql | awk '{print $1}') --ignore-not-found=true 2>/dev/null || true

# And the hostPaths created in the setup step
#
if [ "$OCP" != "" ]; then
    CRC_SSH_KEY=$HOME/.ssh/crc-rsa
    SSH_OPTIONS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i $CRC_SSH_KEY"
    SSH="ssh $SSH_OPTIONS core@api.crc.testing"
    ${SSH} 'sudo sh -c "rm -rf /var/tmp/local-storage"'
else
    # Check /proc/version to determine WSL version.
    # https://github.com/microsoft/WSL/issues/4555#issuecomment-539674785
    # TODO: Use /proc/sys/kernel/osrelease to determine WSL's presence.
    # https://github.com/microsoft/WSL/issues/423#issuecomment-611086412
    [ -d /mnt/wsl ] && [ $(grep -oE 'gcc version ([0-9]+)' /proc/version | awk '{print $3}') -gt 5 ] && isWsl2=1
    if [ $isWsl2 ]; then
        echo "WSL 2 detected."
        if grep -qs "/mnt/wsl/local-storage" /proc/mounts; then sudo umount /mnt/wsl/local-storage; fi
        rm -rf /mnt/wsl/local-storage
        sudo rm -rf /tmp/local-storage
    else
        sudo rm -rf /var/tmp/local-storage/
    fi
fi

