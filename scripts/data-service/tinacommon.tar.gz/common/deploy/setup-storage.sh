#!/bin/bash
set -e
DIR=`dirname $0`

if [ "$OCP" != "" ]; then
    CRC_SSH_KEY=$HOME/.ssh/crc-rsa
    SSH_OPTIONS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i $CRC_SSH_KEY"
    SSH="ssh $SSH_OPTIONS core@api.crc.testing"
    SCP="scp $SSH_OPTIONS"

    # Setup host paths
    #
    $SCP $DIR/setup-local-storage.sh "core@api.crc.testing:/tmp"
    $SSH "sudo sh -c 'source /tmp/setup-local-storage.sh;make_dirs'"
    source $DIR/setup-local-storage.sh; make_pvs
else
    source $DIR/setup-local-storage.sh
    # Check /proc/version to determine WSL version.
    # https://github.com/microsoft/WSL/issues/4555#issuecomment-539674785
    # TODO: Use /proc/sys/kernel/osrelease to determine WSL's presence.
    # https://github.com/microsoft/WSL/issues/423#issuecomment-611086412
    [ -d /mnt/wsl ] && [ $(grep -oE 'gcc version ([0-9]+)' /proc/version | awk '{print $3}') -gt 5 ] && isWsl2=1
    if [ $isWsl2 ]; then echo "WSL 2 detected."; fi
    make_dirs $isWsl2
    make_pvs $isWsl2
fi

