#!/bin/bash

if [ -z $PV_COUNT ]; then
  PV_COUNT=200
fi

get_vol_prefix=/var/tmp/local-storage/vol

function make_pvs {
    
    # Create storage class
    #
    kubectl apply -f - <<EOF
    kind: StorageClass
    apiVersion: storage.k8s.io/v1
    metadata:
      name: local-storage
    provisioner: kubernetes.io/no-provisioner
    volumeBindingMode: WaitForFirstConsumer
EOF
    
    # Create static PVs using local storage
    #
    PV_HOSTNAME=`kubectl get node --no-headers -o jsonpath={.items[0].metadata.name}`
    for i in $(seq 1 $PV_COUNT); do
      PV_NUMBER=$i
    
      # Create half of the PVs for the logs claims, and half for the data claims
      #  
      if [[ $i -lt $((($PV_COUNT / 2) + 1)) ]]
      then
        export PV_SIZE=10Gi # Claimed by the logs
      else
        export PV_SIZE=15Gi # Claimed by the data
      fi
    
      if [ $1 ];
      then
        # On WSL 2 with Docker Desktop, local folders like /var/tmp won't be mounted and accessible by k8s.
        # The folder /mnt/wsl is accessible by both WSL 2 and k8s. Though on k8s, /mnt/wsl is mounted as /run/desktop/mnt/host/wsl. 
        # https://github.com/docker/for-win/issues/5325#issuecomment-632309842
        path=/run/desktop/mnt/host/wsl/local-storage/vol$PV_NUMBER;
      else
        path=${get_vol_prefix}$PV_NUMBER;
      fi

      kubectl apply -f - <<EOF
      kind: PersistentVolume
      apiVersion: v1
      metadata:
        name: pv-mssql-$PV_NUMBER
      spec:
        storageClassName: local-storage
        capacity:
          storage: $PV_SIZE
        accessModes:
          - ReadWriteOnce
        persistentVolumeReclaimPolicy: Delete
        local:
          path: "$path"
        nodeAffinity:
          required:
            nodeSelectorTerms:
            - matchExpressions:
              - key: kubernetes.io/hostname
                operator: In
                values:
                - $PV_HOSTNAME
EOF
    done
}

function make_dirs {
    if [ $1 ];
    then
      # On WSL 2 with Docker Desktop, local folders like /var/tmp won't be mounted and accessible by k8s.
      # The folder /mnt/wsl is accessible by both WSL 2 and k8s.
      # https://github.com/docker/for-win/issues/5325#issuecomment-632309842
      # But /mnt/wsl is mounted from tmpfs which is backed by virtual memory and may haves very limited available space.
      # So we need to create a mount as a sub folder under /mnt/wsl which is backed by a real disk.
      mkdir /mnt/wsl/local-storage
      mkdir /tmp/local-storage
      tmpDir=$(mktemp -d -p /tmp/local-storage)
      sudo mount --bind $tmpDir /mnt/wsl/local-storage
    fi
    for i in $(seq 1 $PV_COUNT); do
        if [ $1 ];
        then
          path=$tmpDir/vol$i;
        else
          path=$get_vol_prefix$i;
        fi
        mkdir -p "$path"
    done
}
