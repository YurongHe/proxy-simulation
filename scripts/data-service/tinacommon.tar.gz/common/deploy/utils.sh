#!/bin/bash

function add-crc-to-resolvconf {
    ip_address=$(ssh agent@WIN_SERVER 'Powershell.exe -Command hvc ip crc' | sed -e 's/\r//g')
    echo "nameserver $ip_address" > /etc/resolvconf/resolv.conf.d/head
    sudo resolvconf -u
    # verify:
    nslookup api.crc.testing
    ssh -o StrictHostKeyChecking=no -i $HOME/.ssh/crc-rsa core@api.crc.testing 'ls / ' || true
}

# To truly check for this, one must check if the Admissions Controller is turned on
# That can be done by checking the start params of the API server
# This is either cumbersome or requires sudo which we don't need to deal with
#
function is-psp-enabled {
    kubectl get psp/privileged > /dev/null 2>&1
    return $?
}
