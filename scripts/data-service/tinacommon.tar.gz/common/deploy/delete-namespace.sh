#!/bin/bash

set -e

kubectl delete namespace ${CLUSTER_NAME} || true
