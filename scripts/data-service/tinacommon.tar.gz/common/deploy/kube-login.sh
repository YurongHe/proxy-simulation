#!/bin/bash

set -e
DIR=`dirname $0`
NAME=$1

source $DIR/utils.sh

function oc_login()
{
    OCP_URL="${OCP_URL:-https://api.crc.testing:6443}"
    case $NAME in
        admin)
            $OC login -u kubeadmin -p kubeadmin --insecure-skip-tls-verify ${OCP_URL}
            ;;
        user)
            $OC login -u kubeuser -p kubeuser --insecure-skip-tls-verify ${OCP_URL}
            ;;
        *)
            echo "No such user: $NAME"
            exit 1
            ;;
    esac
}

function kube_login()
{
    case $NAME in
        admin)
            kubectl config use-context kubeadmin@kubernetes
            ;;
        user)
            kubectl config use-context kubeuser@kubernetes
            ;;
        *)
            echo "No such user: $NAME"
            exit 1
            ;;
    esac
}


if [ "$OCP" != "" ]; then
    oc_login $1
else
    if is-psp-enabled; then
        kube_login $1
    fi
fi
