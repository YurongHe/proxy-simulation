#!/bin/bash -e

if [ $# -lt 2 ]
then
  echo "Usage: windows-local-controller.sh clustername username@hostname"
  exit 2
fi

CLUSTER_NAME=$1
REMOTE_HOST=$2

# Download the kube config
mkdir -p ~/.kube
sftp $REMOTE_HOST:.kube/config ~/.kube/config

# Get the directory of the scripts
SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

# Root directory
ROOT_DIR=$(echo $SCRIPT_DIR | sed "s/^\(\/[a-z]\)\/.*/\1/")

# Controller pod name
CONTROLLER_POD=$(kubectl -n $CLUSTER_NAME get pods -l app=controller -o name | sed 's/^pod\///')

echo "Creating nginx directories"
mkdir -p $ROOT_DIR/opt/openresty/nginx/conf
mkdir -p $ROOT_DIR/opt/openresty/nginx/sites-enabled

echo "Downloading mssql-controller.conf"
CONTROLLER_CONF_DIR=$ROOT_DIR/var/opt/controller/config
mkdir -p $CONTROLLER_CONF_DIR
(kubectl -n $CLUSTER_NAME exec $CONTROLLER_POD -c controller -- cat var/opt/controller/config/mssql-controller.conf) > $CONTROLLER_CONF_DIR/mssql-controller.conf

echo "Downloading controller certificate files"
CONTROLLER_CERT_DIR=$ROOT_DIR/var/run/secrets/certificates/controller
mkdir -p $CONTROLLER_CERT_DIR

for CERT_FILE in controller-certificate.pem controller-privatekey.pem controller-certificate.p12
do
  (kubectl -n $CLUSTER_NAME exec $CONTROLLER_POD -c controller -- cat var/run/secrets/certificates/controller/$CERT_FILE) > $CONTROLLER_CERT_DIR/$CERT_FILE
  echo "+ downloaded $CERT_FILE"
done  

echo "Downloading root CA certificate files"
ROOTCA_CERT_DIR=$ROOT_DIR/var/run/secrets/certificates/rootca
mkdir -p $ROOTCA_CERT_DIR

for CERT_FILE in cluster-ca-certificate.crt cluster-ca-certificate.p12
do
  (kubectl -n $CLUSTER_NAME exec $CONTROLLER_POD -c controller -- cat var/run/secrets/certificates/rootca/$CERT_FILE) > $ROOTCA_CERT_DIR/$CERT_FILE
  echo "+ downloaded $CERT_FILE"
done  

# Set up debug node port for controller database
kubectl apply -f $SCRIPT_DIR/controller-db-debug-nodeport.yaml
echo "To get sa credentials for connecting to controller database, run the following command:"
echo "kubectl -n $CLUSTER_NAME get secret controller-sa-secret -o jsonpath={.data.password} | base64 --decode"

echo "Setting up node admin secrets"
ADMIN_SECRET_DIR=$ROOT_DIR/var/run/secrets/credentials/node-admin-login
mkdir -p $ADMIN_SECRET_DIR
kubectl -n $CLUSTER_NAME get secret node-admin-login-secret -o=jsonpath="{.data.login}" | base64 --decode > $ADMIN_SECRET_DIR/login
kubectl -n $CLUSTER_NAME get secret node-admin-login-secret -o=jsonpath="{.data.password}" | base64 --decode > $ADMIN_SECRET_DIR/password

echo "Done. Before starting the controller locally, update Microsoft.SqlServer.Controller.Service\Program.cs with your node's hostname."