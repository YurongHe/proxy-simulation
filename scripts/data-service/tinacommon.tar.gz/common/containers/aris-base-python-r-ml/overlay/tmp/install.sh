#!/bin/bash -e

# Setup /tmp
#
mkdir -p /tmp
chmod 1777 /tmp

# get $OS_ALIAS and $OS_VERSION
#
source /tmp/platformenv.sh

# Add Microsoft repository
#
curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
curl https://packages.microsoft.com/config/ubuntu/$OS_VERSION/prod.list | tee /etc/apt/sources.list.d/msprod.list

apt-get update

if [ "$OS_ALIAS" == "ubuntu2004" ]; then
    apt-get install -y --no-install-recommends python2 python-setuptools
    update-alternatives --install /usr/bin/python python /usr/bin/python2 1
    curl -sS https://bootstrap.pypa.io/2.7/get-pip.py | python2 - "pip==20.2.4"
    pip2 install cloudpickle pymssql==2.1.5 retrying requests pyyaml protobuf grpcio==1.19.0
fi

# Common variables
#
MS_OPENMPI="microsoft-openmpi"
MLSERVICES_VERSION="${BUILD_MLSERVICES_VERSION}"
MLSERVICES_PREFIX="mssql-mlservices"
# TODO: This next path is 16.04 specific. Does it matter?
# It is used to set up the mssql main repo, presumably that is used in later containers
MLSERVICES_REPO_URL="https://repo.corp.microsoft.com/ubuntu/mssql-mlservices"

# Setup prerequisites
#
apt-get --no-install-recommends -y install curl zip unzip equivs

# Setup mlservices repo
#
REPO_FILE="/etc/apt/sources.list.d/mlserver.list"
if ! [[ -s "$REPO_FILE" ]]; then
        echo "deb [arch=amd64] ${MLSERVICES_REPO_URL} mssql main" > ${REPO_FILE}
fi

curl https://repo.corp.microsoft.com/keys/dpgswdist.v1.asc | apt-key add -
apt-get -q -y update

# Create mssql-server-extensibility placeholder to satisfy requirements
#
cd /tmp
echo -e "Package: mssql-server-extensibility\nDescription: Placeholder for mssql-server-extensibility\nVersion: 99.99.99" > mssql-server-extensibility.ctl
equivs-build mssql-server-extensibility.ctl && dpkg -i mssql-server-extensibility*.deb

# Install basic libraries
#
apt-get -q -y --no-install-recommends install libgomp1

# Install R runtime
#
MS_ROPEN="microsoft-r-open"
MS_ROPEN_VERSION="${BUILD_MS_ROPEN_VERSION}"
MS_ROPEN_MKL="${MS_ROPEN}-mkl-${MS_ROPEN_VERSION}"
MS_ROPEN_MRO="${MS_ROPEN}-mro-${MS_ROPEN_VERSION}"
MS_ROPEN_SPARKLYR="${MS_ROPEN}-sparklyr-${MS_ROPEN_VERSION}"

apt-get -q -y install "${MS_ROPEN_MRO}" "${MS_ROPEN_MKL}" "${MS_OPENMPI}"="${BUILD_MS_OPENMPI_VERSION}" "${MS_ROPEN_SPARKLYR}"

# Download and install RServer (= RevoScaleR, mml-r)
#
MLSERVICES_PACKAGES_R="${MLSERVICES_PREFIX}-packages-r"

apt-get -q -y install "${MLSERVICES_PACKAGES_R}"="${MLSERVICES_VERSION}"

# Download and install Python support
#
PYTHON_HOME=/opt/mls/python
chmod +x Miniconda3-*
./Miniconda3-* -b -p $PYTHON_HOME

pushd $PYTHON_HOME
source bin/activate

conda install -y --file /tmp/reqs.conda.txt
pip install -r /tmp/reqs.pip.txt

conda clean -y --all

ln -sf $PYTHON_HOME/bin/python3 /opt/bin/python3
# restrict access
# ???

source bin/deactivate
popd


# Cleanup
#
if [ "$OS_ALIAS" == "ubuntu2004" ]; then
    # This directory of rhel-specific libs has a libstdc++ that ends up replacing
    # the default one from ubuntu, in the ld lookup path. And that leads to
    # failure of apt-get update
    rm -rf /opt/mssql/mlservices/libraries/RServer/RevoScaleR/rxLibs/x64/rhel/
fi
rm -rf /tmp/* /var/cache/* /etc/apt/sources.list.d/mlserver.list
rm -rf /var/opt/mssql/mssql.conf
