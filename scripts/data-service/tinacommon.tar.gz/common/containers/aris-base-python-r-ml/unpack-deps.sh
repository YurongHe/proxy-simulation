#!/bin/bash -ex

# Layout the build-overlay directory
#
pushd build-overlay

mkdir -p tmp

# Unpack packages
#
tar -xzf ../build-deps/miniconda3-*.gz

# Put programs in their final place
#
mv Miniconda3-* tmp

popd

