#!/bin/bash -ex

chmod a=rwx,o+t /tmp

# Install required packages
#
apt-get update
apt-get install --no-install-recommends -y libdbd-freetds libstatgrab-dev

# Cleanup
#
/opt/bin/cleanup.sh

