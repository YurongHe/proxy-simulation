#!/bin/bash -ex

# Layout the build-overlay directory
#
cd build-overlay

mkdir -p opt/spark
mkdir -p opt/spark-3.0
mkdir -p opt/hive
mkdir -p opt/zookeeper
mkdir -p opt/spark-tools
mkdir -p usr/local
mkdir -p usr/share/java

# Unpack packages
#
tar -xzf ../build-deps/hadoop-*.gz
tar -xzf ../build-deps/sqljdbc_*_*.tar.gz
tar -xvf ../build-deps/async-profiler-*.tar.gz
tar -C opt/zookeeper --strip-components=1 -xzf ../build-deps/zookeeper-*.tar.gz
tar -C opt/spark --strip-components=1 -xzf ../build-deps/spark-2.4*-bin*.tgz
tar -C opt/spark-3.0 --strip-components=1 -xzf ../build-deps/spark-3.0*-bin*.tgz
tar -C opt/hive --strip-components=1 -xzf ../build-deps/hive-metastore-*-bin.tar.gz
unzip -q ../build-deps/livy-0.6*-bin.zip
unzip -q ../build-deps/livy-0.7*-bin.zip

# Put programs in their final place
#
mv async-profiler opt/spark-tools/async-profiler
mv hadoop-* opt/hadoop
mv apache-livy-0.6*-bin/ opt/livy
mv apache-livy-0.7*-bin/ opt/livy-0.7
mv sqljdbc_*/enu/mssql-jdbc*.jar usr/share/java

cp ../build-deps/*.jar opt/spark/jars

rm -rf sqljdbc_*
rm -rf opt/zookeeper/docs

# Put zookeeper jars into hadoop folder 
#
rm -f opt/hadoop/share/hadoop/hdfs/lib/zookeeper* opt/hadoop/share/hadoop/common/lib/zookeeper* opt/livy/jars/zookeeper*.jar
cp opt/zookeeper/lib/zookeeper*.jar opt/hadoop/share/hadoop/hdfs/lib/
cp opt/zookeeper/lib/zookeeper*.jar opt/hadoop/share/hadoop/common/lib/
cp opt/zookeeper/lib/zookeeper*.jar opt/livy/jars/
