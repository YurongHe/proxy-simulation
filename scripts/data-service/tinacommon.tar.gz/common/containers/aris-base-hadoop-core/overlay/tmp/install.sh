#!/bin/bash -ex

# Setup /tmp
#
set -x
mkdir -p /tmp
chmod 1777 /tmp

source /tmp/platformenv.sh
#we care about $OS_ALIAS

# Install required packages
#

if [ "$OS_ALIAS" == "ubuntu" ]; then
   # need python2 packages on ubuntu 16.04
   PACKAGES=python-dev
else
   # need to add libssl-dev on ubuntu 20.04
   PACKAGES=libssl-dev
fi

apt-get update
apt-get install --no-install-recommends -y xmlstarlet gcc python3-dev netcat-openbsd unixodbc mssql-tools $PACKAGES
#
# Python 2 packages, only ubuntu 16.04
#
if [ "$OS_ALIAS" == "ubuntu" ]; then
   pip install --no-deps -r /tmp/requirements-2.txt
   pip check || exit 1
elif [ "$OS_ALIAS" == "ubuntu2004" ]; then
   # in ubuntu 20.04, all python pkgs should be installed in python3
   pip3 install --no-deps -r /tmp/requirements-2.txt
fi

# Python 3 packages, all platforms
pip3 install --no-deps -r /tmp/requirements.txt

pip3 check || exit 1

# Create required directories
#
mkdir -p $LIVY_HOME/logs
mkdir -p $HADOOP_HOME/etc/hadoop
mkdir -p $HADOOP_HOME/logs
mkdir -p $HIVE_HOME/conf
mkdir -p $HIVE_HOME/lib
mkdir -p $SPARK_HOME/jars
mkdir -p $SPARK_CONF_DIR

# Setup symbolic links for Hadoop services
#
ln -sf $HADOOP_CUSTOM_CONF_DIR/core-site.xml $HADOOP_CONF_DIR/core-site.xml
ln -sf $HADOOP_CUSTOM_CONF_DIR/hdfs-site.xml $HADOOP_CONF_DIR/hdfs-site.xml
ln -sf $HADOOP_CUSTOM_CONF_DIR/yarn-site.xml $HADOOP_CONF_DIR/yarn-site.xml
ln -sf $HADOOP_CUSTOM_CONF_DIR/ssl-server.xml $HADOOP_CONF_DIR/ssl-server.xml
ln -sf $HADOOP_CUSTOM_CONF_DIR/capacity-scheduler.xml $HADOOP_CONF_DIR/capacity-scheduler.xml
ln -sf $HADOOP_CUSTOM_CONF_DIR/spark-defaults.conf $SPARK_CONF_DIR/spark-defaults.conf
ln -sf $HADOOP_CUSTOM_CONF_DIR/livy.conf $LIVY_HOME/conf/livy.conf
ln -sf $HADOOP_CUSTOM_CONF_DIR/hive-site.xml $HIVE_HOME/conf/hive-site.xml
ln -sf $HADOOP_CUSTOM_CONF_DIR/hive-site.xml $SPARK_HOME/conf/hive-site.xml
ln -sf $HADOOP_CUSTOM_CONF_DIR/spark-env.sh $SPARK_HOME/conf/spark-env.sh
ln -sf $HADOOP_CUSTOM_CONF_DIR/livy-env.sh $LIVY_HOME/conf/livy-env.sh
ln -sf $HADOOP_CUSTOM_CONF_DIR/hadoop-env.sh $HADOOP_CONF_DIR/hadoop-env.sh
ln -sf $HADOOP_CUSTOM_CONF_DIR/yarn-env.sh $HADOOP_CONF_DIR/yarn-env.sh
ln -sf $HADOOP_CUSTOM_CONF_DIR/mapred-env.sh $HADOOP_CONF_DIR/mapred-env.sh
ln -sf $HADOOP_CUSTOM_CONF_DIR/hdfs-env.sh $HADOOP_CONF_DIR/hdfs-env.sh
ln -sf $HADOOP_CUSTOM_CONF_DIR/hive-env.sh $HIVE_HOME/conf/hive-env.sh
ln -sf $HADOOP_CUSTOM_CONF_DIR/kms-site.xml.tmpl $HADOOP_CONF_DIR/kms-site.xml.tmpl
ln -sf $HADOOP_HOME/etc/hadoop/core-site.xml $SPARK_HOME/conf/core-site.xml
ln -sf $HADOOP_HOME/etc/hadoop/hdfs-site.xml $SPARK_HOME/conf/hdfs-site.xml
ln -sf $HADOOP_CUSTOM_CONF_DIR/spark-history-server.conf.tmpl $SPARK_CONF_DIR/spark-history-server.conf.tmpl
ln -sf $HADOOP_CUSTOM_CONF_DIR/mapred-site.xml $HADOOP_CONF_DIR/mapred-site.xml
ln -sf $HADOOP_CUSTOM_CONF_DIR/kms-acls.xml $HADOOP_CONF_DIR/kms-acls.xml

cp /usr/share/java/mssql-jdbc-7.0.0.jre8.jar $HIVE_HOME/lib/
cp /usr/share/java/mssql-jdbc-7.0.0.jre8.jar $SPARK_HOME/jars/

#add symbolic link for distcp jar.
#
distcpfile=$(readlink -f $HADOOP_HOME/share/hadoop/tools/lib/hadoop-distcp*.jar)
ln -sf $distcpfile $HADOOP_HOME/share/hadoop/tools/lib/hadoop-distcp.jar

# Trim unnecessary files
#
rm -rf /opt/hadoop/share/doc
rm -rf /opt/zookeeper/CHANGES.txt \
    /opt/zookeeper/README.txt \
    /opt/zookeeper/NOTICE.txt \
    /opt/zookeeper/CHANGES.txt \
    /opt/zookeeper/README_packaging.txt \
    /opt/zookeeper/build.xml \
    /opt/zookeeper/config \
    /opt/zookeeper/contrib \
    /opt/zookeeper/dist-maven \
    /opt/zookeeper/docs \
    /opt/zookeeper/ivy.xml \
    /opt/zookeeper/ivysettings.xml \
    /opt/zookeeper/recipes \
    /opt/zookeeper/src \
    /opt/zookeeper/zookeeper-*.jar.asc \
    /opt/zookeeper/zookeeper-*.jar.md5 \
    /opt/zookeeper/zookeeper-*.jar.sha1 \

# Cleanup
#
/opt/bin/cleanup.sh
