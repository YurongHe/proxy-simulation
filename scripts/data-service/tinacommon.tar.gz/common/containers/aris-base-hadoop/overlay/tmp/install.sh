#!/bin/bash

# Setup /tmp
#
mkdir -p /tmp
chmod 1777 /tmp
