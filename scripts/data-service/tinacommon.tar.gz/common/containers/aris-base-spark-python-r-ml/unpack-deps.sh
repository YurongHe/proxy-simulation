#!/bin/bash -ex

# Layout the build-overlay directory
#
cd build-overlay

mkdir -p opt/spark
mkdir -p usr/bin

# Unpack packages
#
tar -C opt/spark --strip-components=1 -xzf ../build-deps/spark-*-bin*.tgz
cp ../build-deps/tini usr/bin/tini