#!/bin/bash -ex

# Setup /tmp
#
mkdir -p /tmp
chmod 1777 /tmp

apt-get update 

apt install -y curl apt-transport-https bash libc6 libpam-modules krb5-user libnss3
mkdir -p /opt/spark 
mkdir -p /opt/spark/examples
mkdir -p /opt/spark/work-dir 
touch /opt/spark/RELEASE

cp /opt/spark/kubernetes/dockerfiles/spark/entrypoint.sh /opt/
cp -r /opt/spark/kubernetes/tests /opt/spark/tests

chmod +x /usr/bin/tini

rm -rf /tmp/* /var/cache/apt/*
