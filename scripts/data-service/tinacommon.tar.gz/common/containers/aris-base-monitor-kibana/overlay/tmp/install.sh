#!/bin/bash -ex

chmod a=rwx,o+t /tmp

# Install required packages
#
apt-get update
apt-get install --no-install-recommends -y fontconfig libfreetype6-dev

# Install OpenDistro kibana plugin
#
OPENDISTRO_SECURITY_PACKAGE=$(realpath $(ls /opt/kibana/opendistro_security_kibana_plugin-*.zip))
/opt/kibana/bin/kibana-plugin --allow-root install file:$OPENDISTRO_SECURITY_PACKAGE
rm -rf $OPENDISTRO_SECURITY_PACKAGE

# Cleanup
#
/opt/bin/cleanup.sh
