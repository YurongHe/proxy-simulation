#!/bin/bash -e

chmod a=rwx,o+t /tmp

# Install the OpenDistro security plugin
#
OPENDISTRO_SECURITY_PACKAGE=$(realpath $(ls /opt/elasticsearch/opendistro_security-*.zip))
/opt/elasticsearch/bin/elasticsearch-plugin install --batch file:$OPENDISTRO_SECURITY_PACKAGE
rm -rf $OPENDISTRO_SECURITY_PACKAGE
