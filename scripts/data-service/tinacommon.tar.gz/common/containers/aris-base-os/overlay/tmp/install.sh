#!/bin/bash -e

chmod a=rwx,o+t /tmp

# Settings
#
export ACCEPT_EULA=Y
export DEBIAN_FRONTEND=noninteractive

# Compress Java runtime .jar files
#
compress_jre_jars()
{
    mkdir charsets
    cd charsets
    unzip -qq ../charsets.jar
    zip -qq -9r ../charsets.jar .
    cd ..
    rm -rf charsets

    mkdir rt
    cd rt
    unzip -qq ../rt.jar
    zip -qq -9r ../rt.jar .
    cd ..
    rm -rf rt
}

source /tmp/platformenv.sh
#$OS_NAME $OS_VERSION $OS_ALIAS $OS_NICKNAME

# Choose the correct installer source list
#
if [ "$OS_ALIAS" == "ubuntu" ]; then
    mv /etc/apt/sources.list.ubuntu /etc/apt/sources.list
    rm /etc/apt/sources.list.ubuntu2004
elif [ "$OS_ALIAS" == "ubuntu2004" ]; then
    mv /etc/apt/sources.list.ubuntu2004 /etc/apt/sources.list
    rm /etc/apt/sources.list.ubuntu
fi

# Install base packages
# The sync commands are to work around a bug in overlayfs where filesystem
# metadata can be corrupted/out of sync during apt calls inside docker builds
#
sync
apt-get update
sync
if [ "$OS_ALIAS" == "ubuntu" ]; then
    PACKAGES="libcurl3 libjemalloc1 libpython3.5-dev libssl1.0.2 python-pip python-setuptools"
elif [ "$OS_ALIAS" == "ubuntu2004" ]; then
    PACKAGES="gpg-agent libcurl4 libjemalloc2 libpython3.8-dev libssl1.1 python3-gi python3-gi-cairo python3-pip"
fi

apt-get install --no-install-recommends -y wget curl apt-transport-https build-essential \
        software-properties-common locales net-tools xmlstarlet \
        libunwind8 libnuma1 libc++1 openssl python3 libgssapi-krb5-2 \
        gawk sed lsof pbzip2 libldap-2.4-2 libsasl2-2 \
        libsasl2-modules-gssapi-mit tzdata freetds-bin iputils-ping python3-tk fakechroot \
        tar libfontconfig zip unzip snmp procps ca-certificates python3-setuptools \
        gettext-base dnsutils gettext rdfind netcat-openbsd krb5-user krb5-config \
        libcurl4-openssl-dev perl libpcre3 inotify-tools libkrb5-dev \
        unixodbc-dev unixodbc sudo $PACKAGES

echo "en_US.UTF-8 UTF-8" > /etc/locale.gen && locale-gen

if [ "$OS_ALIAS" == "ubuntu" ] ; then
    # Install Custom Krb5
    #
    dpkg -i /tmp/krb5/libkrb5support0_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb
    dpkg -i /tmp/krb5/libk5crypto3_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb
    dpkg -i /tmp/krb5/libkrb5-3_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb 
    dpkg -i /tmp/krb5/libgssrpc4_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb
    dpkg -i /tmp/krb5/libgssapi-krb5-2_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb
    dpkg -i /tmp/krb5/libkadm5srv-mit9_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb
    dpkg -i /tmp/krb5/libkadm5clnt-mit9_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb
    dpkg -i /tmp/krb5/krb5-multidev_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb
    dpkg -i /tmp/krb5/libkrb5-dev_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb
    dpkg -i /tmp/krb5/krb5-user_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb
    dpkg -i /tmp/krb5/libgssapi-krb5-2_1.13.2+dfsg-5ubuntu2.1.1-hls_amd64.deb

elif [ "$OS_ALIAS" == "ubuntu2004" ]; then
    # Ubuntu 20.04 has newer packages, use those
    apt-get install --no-install-recommends -y libkrb5support0 libk5crypto3 libkrb5-3 libgssrpc4 libgssapi-krb5-2 \
        libkadm5srv-mit11 libkadm5clnt-mit11  krb5-multidev libkrb5-dev krb5-user libgssapi-krb5-2
fi

# Add Microsoft repository
#
curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
curl https://packages.microsoft.com/config/ubuntu/$OS_VERSION/prod.list | tee /etc/apt/sources.list.d/msprod.list

# Internal Repo
# This will be cleaned up before exit
#
curl -L -o /tmp/pubkey.asc https://helsinki.redmond.corp.microsoft.com/dist/repos/keys/dpgswdist.v1.asc
apt-key add /tmp/pubkey.asc
curl https://repo.corp.microsoft.com/ubuntu/config/mssql-zulu-jre.list| tee /etc/apt/sources.list.d/zulu.list
# end of internal repo

apt-get update

# Install packages from Microsoft repository
#
apt install --no-install-recommends -y mssql-zulu-jre-8=8.50.0.52-1 
apt install --no-install-recommends -y mssql-zulu-jre-11=11.43.56-1

# Override the default license text, per legal requirements for Arc
cp /tmp/license_Java_Runtime.txt /usr/share/doc/mssql-zulu-*8
cp /tmp/license_Java_Runtime.txt /usr/share/doc/mssql-zulu-*11

# Now that Zulu Java is installed, refresh the ca-certificates so the Zulu ca-certiciate hook is run and the
# default certificates are added
# 
update-ca-certificates --fresh

# Compress JRE jars for Azul Zulu JRE version 8
#
pushd /opt/mssql/lib/zulu-jre-8/lib
compress_jre_jars
popd

# Update locale information
#
echo "en_US.UTF-8 UTF-8" > /etc/locale.gen && locale-gen

# Install essential Python packages
#
if [ "$OS_ALIAS" == "ubuntu" ] ; then
    # on ubuntu 16.04 we support python2 and python3
    # Upgrade pip to 20.2.4
    #
    curl -sS https://bootstrap.pypa.io/3.5/get-pip.py | python3 - "pip==20.2.4"
    python -m pip install -U pip==20.2.4

    pip2 install cloudpickle pymssql==2.1.5 retrying requests pyyaml protobuf grpcio==1.19.0
    GRPCIO_VERSION=1.19.0
else
    curl -sS https://bootstrap.pypa.io/get-pip.py | python3 - "pip==20.2.4"
    GRPCIO_VERSION=1.25.0
fi

pip3 install cloudpickle pymssql==2.1.5 retrying requests pyyaml protobuf grpcio==$GRPCIO_VERSION

# all platforms support pip3 and need supervisor
pip3 install --ignore-installed /tmp/supervisor-4.2.1-py2.py3-none-any.whl --prefix=/usr/local

# Cleanup the internal repo
#
apt-key del `gpg --list-packets < /tmp/pubkey.asc | grep keyid | head -1 | cut -d: -f2`
rm -f /etc/apt/sources.list.d/zulu.list

# Cleanup
#
/opt/bin/cleanup.sh

