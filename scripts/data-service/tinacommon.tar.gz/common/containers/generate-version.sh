#!/bin/bash

BASEDIR=$(dirname $(realpath $0))

cd $BASEDIR
VERSIONS_FILE="../../../build/versions.mk"
echo $(git ls-files .) "$VERSIONS_FILE" | xargs cat | sha256sum | cut -f1 -d' '
