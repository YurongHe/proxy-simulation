#!/bin/bash -ex

export ACCEPT_EULA=Y

# Set /tmp permissions
#
chmod 1777 /tmp

# Download the Microsoft repository GPG keys (to Powershell and SqlServer module (to enable Invoke-SqlNotebook)
#
source /tmp/platformenv.sh
wget -q https://packages.microsoft.com/config/ubuntu/$OS_VERSION/packages-microsoft-prod.deb

# Register the Microsoft repository GPG keys (to Powershell and SqlServer module (to enable Invoke-SqlNotebook)
#
dpkg -i packages-microsoft-prod.deb

# Install required packages
#

# Install libgit2 which is required to install gert (git client for R) which is needed for sparklyr installation
# https://github.com/r-lib/gert/issues/107
#
if [ "$OS_ALIAS" == "ubuntu" ] ; then
    # For ubuntu 16 we need to pull libgit2-dev from a special
    # repo. This is not the case for ubuntu 20.
    #
    add-apt-repository -y ppa:cran/libgit2
    # We also need to add the openjdk repo
    #
    add-apt-repository -y ppa:openjdk-r/ppa

    PACKAGES="python-pip python-dev msodbcsql python-lxml openjdk-8-jdk"

elif [ "$OS_ALIAS" == "ubuntu2004" ]; then
    # for ubuntu 20, I had trouble getting openjdk to install/configure.
    # Dependency issues.
    # Since we have zulu jre 8 installed already, set it as default jaava
    update-alternatives --install /usr/bin/java java /opt/mssql/lib/zulu-jre-8/bin/java 1 

    PACKAGES="libpangocairo-1.0-0 python3-lxml python3-pycurl"
fi

apt-get update
apt-get install --no-install-recommends -y software-properties-common gcc \
	g++ unixodbc unixodbc-dev unzip libssl-dev \
	libffi-dev jq python3-venv msodbcsql17 \
	python3-dev moreutils build-essential libcurl4-openssl-dev \
	libxml2-dev vim powershell pandoc libkrb5-dev libgit2-dev $PACKAGES

if [ "$OS_ALIAS" == "ubuntu" ] ; then
    add-apt-repository -y --remove ppa:cran/libgit2
fi

if [ "$OS_ALIAS" == "ubuntu2004" ]; then
    # TEMPORARILY install python2 into the test base image. Livy/spark tests
    # still require it. We should get rid of it ASAP.
    #
    apt-get install --no-install-recommends -y python2 python-dev python-lxml
    update-alternatives --install /usr/bin/python python /usr/bin/python2 1
    curl -sS https://bootstrap.pypa.io/2.7/get-pip.py | python2 - "pip==20.2.4"
    # Leaving these module installs in the ubuntu2004 clause explicitly, because
    # I hope we will get rid of python2 in 20.04, and it will be easier to clean
    # it all up if the "overrides" are kept together.
    #
    python2 -m pip install -r /tmp/pip2-requirements.txt
fi

# Install SqlServer module (into Powershell)
#
pwsh -Command "Install-Module -Name SqlServer -force"

# Install required Python packages
#
if [ "$OS_ALIAS" == "ubuntu" ] ; then
    pip install -r /tmp/pip2-requirements.txt
fi
pip3 install -r /tmp/pip3-requirements.txt

# Install Python/Jupyter used by ADS into the ADS sandbox location
#
# The fwlink used here comes from the source code ADS uses to download the Python/Jupyter sandbox:
#
#     https://github.com/Microsoft/azuredatastudio/blob/master/extensions/notebook/src/jupyter/jupyterServerInstallation.ts
#
if [ "$OS_ALIAS" == "ubuntu" ] ; then
    # On ubuntu 16, we need to install python3.6. We'll get that from ads
    #
    wget -nv https://go.microsoft.com/fwlink/?linkid=2065975 -O python-linux-x64.tar.gz
    mkdir -p $HOME/azuredatastudio-python
    tar -xf python-linux-x64.tar.gz -C $HOME/azuredatastudio-python
    rm python-linux-x64.tar.gz
fi

# Install required Python packages (to execute adsbook notebooks) into ADS sandbox
#
if [ "$OS_ALIAS" == "ubuntu" ] ; then
    $HOME/azuredatastudio-python/0.0.1/bin/python3.6 -m pip install -r /tmp/pip3-ads-requirements.txt
elif [ "$OS_ALIAS" == "ubuntu2004" ]; then
    python3 -m pip install -r /tmp/pip3-ads-requirements.txt
fi

# Install nodejs
#
curl -sSL https://deb.nodesource.com/gpgkey/nodesource.gpg.key | apt-key add -
add-apt-repository -s "deb https://deb.nodesource.com/node_10.x $OS_NICKNAME main"
apt-get update
apt-get install --no-install-recommends -y nodejs
npm install -g mocha

if [ "$OS_ALIAS" == "ubuntu2004" ]; then
   add-apt-repository "deb http://security.ubuntu.com/ubuntu xenial-security main"
   apt-get update
   apt-get -q -f install libicu55 -y
   add-apt-repository --remove "deb http://security.ubuntu.com/ubuntu xenial-security main"
   apt-get update
fi

# Setup repo for openmpi. Note use of common ubuntu repo here. The
# microsoft-openmpi package is the same on both platforms.
#
MS_OPENMPI="microsoft-openmpi"
MLSERVICES_REPO_URL="https://repo.corp.microsoft.com/ubuntu/mssql-mlservices"
REPO_FILE="/etc/apt/sources.list.d/mlserver.list"
if ! [[ -s "$REPO_FILE" ]]; then
    echo "deb [arch=amd64] ${MLSERVICES_REPO_URL} mssql main" > ${REPO_FILE}
fi

curl https://repo.corp.microsoft.com/keys/dpgswdist.v1.asc | apt-key add -
apt-get -q -y update
apt-get -q -f install ${MS_OPENMPI} -y
rm /etc/apt/sources.list.d/mlserver.list
apt-get -q -y update

# Install R runtime
#
MS_ROPEN="microsoft-r-open"
MS_ROPEN_VERSION="3.5.2"
MS_ROPEN_MKL="${MS_ROPEN}-mkl-${MS_ROPEN_VERSION}"
MS_ROPEN_MRO="${MS_ROPEN}-mro-${MS_ROPEN_VERSION}"
MS_ROPEN_SPARKLYR="${MS_ROPEN}-sparklyr-${MS_ROPEN_VERSION}"

apt-get -q -f install "${MS_ROPEN_MRO}" "${MS_ROPEN_MKL}" "${MS_ROPEN_SPARKLYR}" -y

# Update sparklyr package to use precompiled JARs
# Issue: https://github.com/rstudio/sparklyr/issues/2016
#
export USE_SYSTEM_LIBGIT2=1
Rscript -e "install.packages('curl', repos = 'https://cloud.r-project.org/')"
Rscript -e "if (length(find.package('devtools', quiet = TRUE))) remove.packages('devtools')"
Rscript -e "install.packages('devtools', repos = 'https://cloud.r-project.org/')"
Rscript -e "if (length(find.package('sparklyr', quiet = TRUE))) remove.packages('sparklyr')"

Rscript  -e "install.packages('later', repos='https://cran.rstudio.com/')"
# Issue: https://github.com/r-lib/remotes/issues/350
#
Rscript -e "options('download.file.method' = 'libcurl'); devtools::install_github('rstudio/sparklyr', ref = '71cf3db', upgrade = 'always', repos = 'https://cran.microsoft.com/snapshot/2020-07-10/')"

# Install mssql-tools
#
apt-get install -y mssql-tools

# Install adutil
#
if [ "$OS_ALIAS" == "ubuntu" ] ; then
    # TODO: adutil depends on python-software-properties which is not available in
    # ubuntu 20.04. Either will need to support python2 and pull python-software-properties
    # from an older repo (18 should have it) or get a modern 20.04 version of adutil.
    wget -qO- https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
    add-apt-repository "$(wget -qO- https://packages.microsoft.com/config/ubuntu/16.04/mssql-server-preview.list)"
    apt-get update
    apt-get install -y adutil
fi

# Cleanup
#
/opt/bin/cleanup.sh

