#!/bin/bash -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

BUILD_DEPS=$DIR/build-deps
BUILD_OVERLAY=$DIR/build-overlay

mkdir -p ${BUILD_OVERLAY}
pushd ${BUILD_OVERLAY}

# Create common directories
#
mkdir -p opt
mkdir -p usr/local

# Unpack Hadoop
#
tar -xzf ${BUILD_DEPS}/hadoop-*.tar.gz
mv hadoop-* opt/hadoop

# Unpack Spark
#
tar -xzf ${BUILD_DEPS}/spark-*.tgz
mv spark-*-bin-* opt/spark

mv ${BUILD_DEPS}/metrics-influxdb-*.jar opt/spark/jars/
mv ${BUILD_DEPS}/spark-influx-sink-*.jar opt/spark/jars/

# Unpack Apache Livy
#

mkdir -p tests/livy/jars
unzip -qq ${BUILD_DEPS}/livy-*-bin.zip
cp apache-livy-*-bin/jars/* tests/livy/jars
rm -rf apache-livy-*-bin

# Unpack livy test jars
#
tar -xf ${BUILD_DEPS}/livy-test-*.tar
cp livy-test/jars/* tests/livy/jars
cp -r livy-test/* tests/livy
rm -rf livy-test

cp opt/spark/jars/spark-core_*.jar tests/livy/jars/
cp opt/spark/jars/spark-hive_*.jar tests/livy/jars/
cp opt/spark/jars/spark-sql_*.jar tests/livy/jars/

# Unpack tpcds test dataset
#
mkdir -p tests/tpcds
mkdir -p tests/tpcds/dataset
tar -xzf ${BUILD_DEPS}/tpcds-dataset-*.tar.gz
mv ./sf1-parquet tests/tpcds/dataset/

# Unpack Hibench project
# 
mkdir hibench
tar -xzf ${BUILD_DEPS}/hibench.7.0.4.tgz -C hibench/
mv hibench* tests

# Unpack kubectl
#
tar -xzf ${BUILD_DEPS}/kubernetes-client-linux-386.tar.gz 
chmod a+x kubernetes/client/bin/kubectl
mkdir -p usr/bin
mv kubernetes/client/bin/kubectl usr/bin

# Unpack testshell
#
mkdir -p tests/testshell/external
tar -xzf ${BUILD_DEPS}/testshell.frontend.tar -C tests/testshell/external
chmod a+x tests/testshell/external/bin/testshell
tar -xzf ${BUILD_DEPS}/environment.tar -C tests/testshell/external
cp ${BUILD_DEPS}/sqlcl.tar.gz tests/testshell/external

# Copy in pansop
#
mkdir -p tests/adsbooks/external/pansop
cp ${BUILD_DEPS}/pansop/pansop tests/adsbooks/external/pansop

# Temporarily fix up environment.xml until a new one is uploaded to helsinki/dist
sed -i -e 's/<Variable Name="TESTFILESROOT" Value="c:\\tests\\testshell\\external\\sqlcl" \/>/<Variable Name="SkipPolybaseSetupCleanup" Value="True" \/><Variable Name="TESTFILESROOT" Value="c:\\external\\sqlcl" \/>/g' tests/testshell/external/environment.xml

# Cleanup conflict netty libraries
#
rm tests/livy/jars/netty-3.9*.jar
rm tests/livy/jars/netty-all-4*.jar
