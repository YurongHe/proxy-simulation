#!/bin/bash -e
# This script takes a list of ips as input. 
# The first ip is the ip of master host, followed by the ips of worker hosts.
# This script starts kubeadm at master host, and
# joins all the worker nodes specified by the input ips to the master host.

if [ $# -eq 0 ]
  then echo "Please specify the master ip as the first argument of this script"
  exit
fi
export MASTER_IP=$1
shift

# Get the directory of the scripts
SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
# Start kubeadm at master host
echo -e "\e[42mstarting k8s on master `hostname`\e[0m"
$SCRIPT_DIR/start-kubeadm.sh
TOKEN=`kubeadm token create`
echo -e "will use token $TOKEN to join master"
while [ $# -gt 0 ]
do
    # sometimes, people add non-breaking space characters to their *host* files.
    WORKER_IP=$(echo "$1" | sed -e 's/\xC2\xA0//g')
    echo -e "\e[42mstarting k8s on worker ${WORKER_IP}\e[0m"
    # Copy the scripts to worker nodes
    scp -oStrictHostKeyChecking=no $SCRIPT_DIR/common-node.sh root@$WORKER_IP:/root/common-node.sh
    scp -oStrictHostKeyChecking=no $SCRIPT_DIR/nuke-graph-directory.sh root@$WORKER_IP:/root/nuke-graph-directory.sh
    scp -oStrictHostKeyChecking=no $SCRIPT_DIR/prepare-kubeadm.sh root@$WORKER_IP:/root/prepare-kubeadm.sh
    # Start kubeadm at worker nodes
    ssh -oStrictHostKeyChecking=no root@$WORKER_IP "/root/prepare-kubeadm.sh $DOCKER_DIR $KUBELET_DIR $DOCKER_DIR_CLEAN"
    ssh -oStrictHostKeyChecking=no root@$WORKER_IP "kubeadm join --token $TOKEN --discovery-token-unsafe-skip-ca-verification $MASTER_IP:6443"
    shift
done
